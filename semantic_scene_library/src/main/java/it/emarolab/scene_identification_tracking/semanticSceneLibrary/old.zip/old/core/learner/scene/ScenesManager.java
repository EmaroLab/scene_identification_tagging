package it.emarolab.scene_identification_tracking.semanticSceneLibrary.old.core.learner.scene;

import it.emarolab.scene_identification_tracking.semanticSceneLibrary.old.Logger;
import it.emarolab.scene_identification_tracking.semanticSceneLibrary.old.core.Semantics;
import it.emarolab.scene_identification_tracking.semanticSceneLibrary.old.core.semantics.SceneSemantics;

import java.util.HashSet;
import java.util.Set;

public interface ScenesManager {

    // todo: move to Semantics
    interface Learner<T> extends Semantics{
        default LearningState learnSemantics(){
            LearningState stateLearn = new LearningState();
            stateLearn = stateLearn.merge( readSemantics());
            stateLearn = stateLearn.merge( learnSemantics(getTemplates()));
            stateLearn = stateLearn.merge( writeSemantics());
            // todo log
            return stateLearn;
        }

        LearningState learnSemantics( T templates);

        T getTemplates();

    }
    class LearningState extends Semantics.MappingState{

        // todo add state Learned
        // todo add Tryier
    }

    class SceneSet extends Logger.SITBase implements Learner<Set<SceneTemplate>>{ // todo add MORDescriptor

        private SceneSemantics representation;
        private Set<SceneTemplate> templates = new HashSet<>();

        public SceneSet( SceneSemantics representation){ // to create here !!!
            this.representation = representation;
        }

        public SceneSemantics getRepresentation() {
            return representation;
        }
        public Set<SceneTemplate> getTemplates() {
            return templates;
        }



        @Override
        public LearningState learnSemantics(Set<SceneTemplate> templates) {
            return null;
        }


        @Override
        public LearningState learnSemantics() {
            LearningState state = new LearningState();
            log( "------------------** MANAGER START LEARNING **---------------------------");

            Set<SceneTemplate> ts = getTemplates();
            ts.remove( representation.getOntology().getOWLClass("Scene")); // todo !!!!!!!!!!!
            if( ts.isEmpty()) {
                SceneTemplate t = new SceneTemplate(representation.getOntology(), "", true);  // todo !!!!!!!!!!!

                String debug = "Is " + this.getRepresentation().getIndividualName() + " a representation of the Scene: " +
                        t.getInstanceName() + "?"; // todo extend description and get ontology


                t.readSemantics();
                SceneTemplate.LearningResults results = t.learn(representation);
                if (results.shouldBeLearned()) {
                    results.getLearnedScene().writeSemantics();
                    templates.add(results.getLearnedScene());
                    debug += " YES ";
                } else debug += " NO  ";


                log(debug + " Conf:" + results.getConfidence() + " = " + results.getIndividualCardinality()
                        + "/" + results.getConceptCardinality() + ".\tTemplates: " + getTemplates());
            } else {


                //for (OWLClass cl : representation.getTypes()) {}
                for (SceneTemplate s : getTemplates()) {


                    String debug = "########### Is " + this.getRepresentation().getIndividualName() + " a representation of the Scene: " +
                            s.getInstanceName() + "?"; // todo extend description and get ontology

                    SceneTemplate t = new SceneTemplate(representation.getOntology(),
                            s.getInstance(), false);
                    t.readSemantics();
                    SceneTemplate.LearningResults results = t.learn(representation);
                    if (results.shouldBeLearned()) {
                        results.getLearnedScene().writeSemantics();
                        templates.add(results.getLearnedScene());
                        debug += " YES ";
                        break;
                    } else debug += " NO  ";


                    log(debug + " Conf:" + results.getConfidence() + " = " + results.getIndividualCardinality()
                            + "/" + results.getConceptCardinality() + ".\tTemplates: " + getTemplates());
                }
            }

            representation.getOntology().applyOWLManipulatorChanges();
            representation.getOntology().synchronizeReasoner();


            log( "------------------**           END LEARNING **----- state : " + state);
            return state; // todo to set
        }

        @Override
        public WritingState writeSemantics() { // writes all templates and representation
            log( "------------------**  MANAGER START WRITING **---------------------------");
            WritingState state = new WritingState();

            for ( SceneTemplate s : templates)
                state = state.merge( s.writeSemantics());

            state = state.merge( this.representation.writeSemantics());

            log( "------------------**            END WRITING **----- state : " + state);
            return state;
        }
        @Override
        public ReadingState readSemantics() {// reads all templates and representation
            log( "------------------**  MANAGER START READING **---------------------------");
            ReadingState state = new ReadingState();

            // todo manage template

            state = state.merge( this.representation.readSemantics());


            log( "------------------**            END READING **----- state : " + state);
            return state;
        }


        //todo add static load all

    }

}
