package it.emarolab.scene_identification_tracking.semanticSceneLibrary.old.core.aMORDescriptor;

import it.emarolab.amor.owlInterface.OWLReferences;
import it.emarolab.scene_identification_tracking.semanticSceneLibrary.old.Logger;
import it.emarolab.scene_identification_tracking.semanticSceneLibrary.old.core.Semantics;
import org.semanticweb.owlapi.model.OWLClass;
import org.semanticweb.owlapi.model.OWLNamedIndividual;
import org.semanticweb.owlapi.model.OWLObjectProperty;

import java.util.ArrayList;
import java.util.Collection;
import java.util.LinkedHashMap;
import java.util.List;

// this consider unique property (replaces) todo: add for multiple
public interface MORLinkedIndividualDescriptor
        extends MORDescriptor.MORIndividualDescriptor,
        Semantics.LinkedInstanceDescriptor<OWLReferences, OWLNamedIndividual, OWLObjectProperty> {

    @Override
    LinkedHashMap<OWLObjectProperty, OWLNamedIndividual> getLinkedInstance();

    default void clearLinekdIndividual(){
        getLinkedInstance().clear();
    }

    default List< OWLObjectProperty> getAllLinks(){
        List< OWLObjectProperty> out = new ArrayList<>();
        for ( OWLObjectProperty o : getLinkedInstance().keySet())
            out.add( o);
        return out;
    }
    default List< OWLNamedIndividual> getAllLinkedInstance(){
        List< OWLNamedIndividual> out = new ArrayList<>();
        for ( OWLObjectProperty o : getLinkedInstance().keySet())
            out.add( getLinkedInstance( o));
        return out;
    }

    default void linkInstance(OWLObjectProperty property){
        getLinkedInstance().put( property, null);
    }
    default void linkInstance(String propertyName){
        OWLObjectProperty property = getOntology().getOWLObjectProperty( propertyName);
        linkInstance( property);
    }

    default void linkInstance(OWLObjectProperty property, OWLNamedIndividual individual){
        getLinkedInstance().put(property, individual);
    }
    default void linkInstance(String propertyName, String individualName){
        OWLObjectProperty property = getOntology().getOWLObjectProperty( propertyName);
        OWLNamedIndividual individual = getOntology().getOWLIndividual( individualName);
        linkInstance(property, individual);
    }

    default OWLNamedIndividual removeLinkedIndividual(OWLObjectProperty property) {
        return getLinkedInstance().remove(property);
    }
    default OWLNamedIndividual removeLinkedIndividual(OWLNamedIndividual individual){
        OWLObjectProperty key = getLinkedProperty( individual);
        return getLinkedInstance().remove(key);
    }

    default OWLNamedIndividual getLinkedInstance(OWLObjectProperty property){
        return getLinkedInstance().get( property);
    }
    default OWLNamedIndividual getLinkedInstance(String property){
        return getLinkedInstance( getOntology().getOWLObjectProperty( property));
    }
    default String getLinkedInstanceName(OWLObjectProperty property){
        return getOWLName( getLinkedInstance( property));
    }
    default String getLinkedInstanceName(String property){
        return getOWLName( getLinkedInstance( property));
    }

    default OWLObjectProperty getLinkedProperty( OWLNamedIndividual value){
        for( OWLObjectProperty p : getLinkedInstance().keySet()){
            if( getLinkedInstance( p).equals( value))
                    return p;
        }
        return null;
    }
    default OWLObjectProperty getLinkedProperty( String value){
        return getLinkedProperty( getOntology().getOWLIndividual( value));
    }
    default String getLinkedPropertyName( OWLNamedIndividual value){
        return getOWLName( getLinkedProperty( value));
    }
    default String getLinkedPropertyName( String value){
        return getOWLName( getLinkedProperty( value));
    }

    default OWLNamedIndividual getPropertyObject( String propertyName){
        OWLObjectProperty prop = getOntology().getOWLObjectProperty( propertyName);
        return getPropertyObject( prop);
    }
    // calls always ontoRef...Only... todo change for multiple properties
    default OWLNamedIndividual getPropertyObject(OWLObjectProperty property){
        return getOntology().getOnlyObjectPropertyB2Individual( getInstance(), property);
    }

    @Override
    default Semantics.ReadingState readLinkedInstance(String debug, OWLObjectProperty property){
        return new Logger.MappingTry<Semantics.ReadingState>() {
            @Override
            protected Semantics.ReadingState giveAtry() {
                Semantics.ReadingState state = new Semantics.ReadingState();
                OWLNamedIndividual javaValue = getLinkedInstance( property);
                OWLNamedIndividual semanticValue = getOntology().getOnlyObjectPropertyB2Individual(getInstance(), property);

                if( semanticValue == null) { // does not exist
                    if (javaValue == null){
                        state.asNotChanged();
                        debugging( state, javaValue, semanticValue);
                    } else {
                        removeLinkedIndividual( property);
                        state.asAbsent();
                        debugging( state, javaValue, semanticValue);
                    }
                } else {
                    if (javaValue == null){
                        linkInstance( property, semanticValue);
                        state.asSuccess();
                        debugging( state, javaValue, semanticValue);
                    } else {
                        if ( semanticValue.equals( javaValue)){
                            state.asNotChanged();
                            debugging( state, javaValue, semanticValue);
                        } else{
                            linkInstance( property, semanticValue);
                            state.asSuccess();
                            debugging( state, javaValue, semanticValue);
                        }
                    }
                }
                return state;
            }
            private void debugging(Semantics.ReadingState state, OWLNamedIndividual java, OWLNamedIndividual owl){
                log(this.getClass().getSimpleName() + "\t WRITES PROPERTY: \"" + getInstanceName()
                        + " (" + debug + ")"
                        + "\t\t " + getInstanceName() + " "
                        + getStringfixedLength( getOWLName( property), LOGGING_NAME_LENGTH, true) + "."
                        + getStringfixedLength( getOWLName( java), LOGGING_SHORT_NAME_LENGTH, false)
                        + "\t(was in ontology: "
                        + getStringfixedLength( getOWLName( property), LOGGING_NAME_LENGTH, true) + "."
                        + getStringfixedLength( getOWLName( owl), LOGGING_SHORT_NAME_LENGTH, false)
                        + ")\t\t[" + state + "]");
            }
        }.perform();
    }

    @Override
    default Semantics.WritingState writeLinkedInstance(String debug, OWLObjectProperty property) {
        return new Logger.MappingTry<Semantics.WritingState>() {
            @Override
            protected Semantics.WritingState giveAtry() {
                Semantics.WritingState state = new Semantics.WritingState();
                OWLNamedIndividual javaValue = getLinkedInstance( property);
                OWLNamedIndividual semanticValue = getOntology().getOnlyObjectPropertyB2Individual(getInstance(), property);

                if( semanticValue == null) { // does not exist
                    if (javaValue == null){
                        state.asNotChanged();
                        debugging( state, javaValue, semanticValue);
                    } else {
                        // ADD
                        getOntology().addObjectPropertyB2Individual( getInstance(), property, javaValue);
                        state.asAdded();
                        debugging( state, javaValue, semanticValue);
                    }
                } else {
                    if (javaValue == null){
                        // REMOVE
                        getOntology().removeObjectPropertyB2Individual( getInstance(), property, javaValue);
                        state.asRemoved();
                        debugging( state, javaValue, semanticValue);
                    } else {
                        if ( semanticValue.equals( javaValue)){
                            state.asNotChanged();
                            debugging( state, javaValue, semanticValue);
                        } else{
                            // REPLACE
                            getOntology().replaceObjectProperty( getInstance(), property, javaValue, semanticValue);
                            state.asUpdated();
                            debugging( state, javaValue, semanticValue);
                        }
                    }
                }
                return state;
            }
            private void debugging(Semantics.WritingState state, OWLNamedIndividual java, OWLNamedIndividual owl){
                log(this.getClass().getSimpleName() + "\t READS PROPERTY: \"" + getInstanceName()
                        + " (" + debug + ")"
                        + "\t\t " + getInstanceName() + " "
                        + getStringfixedLength( getOWLName( property), LOGGING_NAME_LENGTH, true) + "."
                        + getStringfixedLength( getOWLName( owl), LOGGING_SHORT_NAME_LENGTH, false)
                        + "\t(was in java: "
                        + getStringfixedLength( getOWLName( property), LOGGING_NAME_LENGTH, true) + "."
                        + getStringfixedLength( getOWLName( java), LOGGING_SHORT_NAME_LENGTH, false)
                        + ")\t\t[" + state + "]");
            }
        }.perform();
    }

    class SimpleLinkedIndividual extends MORTypedIndividualDescriptor.SimpleTypedIndividual
            implements MORLinkedIndividualDescriptor {

        private LinkedHashMap<OWLObjectProperty, OWLNamedIndividual> linkingMap = new LinkedHashMap<>();

        public SimpleLinkedIndividual(SimpleLinkedIndividual copy) {
            super(copy);
            this.linkingMap = new LinkedHashMap<>( copy.linkingMap);
        }
        public SimpleLinkedIndividual(String ontoRef, String individual, String type) {
            super(ontoRef, individual, type);
        }
        public SimpleLinkedIndividual(OWLClass type) {
            super(type);
        }
        public SimpleLinkedIndividual(String ontoRef, OWLClass type) {
            super(ontoRef, type);
        }
        public SimpleLinkedIndividual(OWLReferences ontoRef, OWLClass type) {
            super(ontoRef, type);
        }
        public SimpleLinkedIndividual(OWLNamedIndividual ontoRef, OWLClass type) {
            super(ontoRef, type);
        }
        public SimpleLinkedIndividual(String ontoRef, String individual, OWLClass type) {
            super(ontoRef, individual, type);
        }
        public SimpleLinkedIndividual(OWLReferences ontoRef, OWLNamedIndividual individual, OWLClass type) {
            super(ontoRef, individual, type);
        }
        public SimpleLinkedIndividual(Collection<?> types) {
            super(types);
        }
        public SimpleLinkedIndividual(String ontoRef, Collection<?> types) {
            super(ontoRef, types);
        }
        public SimpleLinkedIndividual(OWLReferences ontoRef, Collection<?> types) {
            super(ontoRef, types);
        }
        public SimpleLinkedIndividual(OWLNamedIndividual ontoRef, Collection<?> types) {
            super(ontoRef, types);
        }
        public SimpleLinkedIndividual(String ontoRef, String individual, Collection<?> types) {
            super(ontoRef, individual, types);
        }
        public SimpleLinkedIndividual(OWLReferences ontoRef, OWLNamedIndividual individual, Collection<?> types) {
            super(ontoRef, individual, types);
        }

        @Override
        public LinkedHashMap<OWLObjectProperty, OWLNamedIndividual> getLinkedInstance() {
            return linkingMap;
        }

        @Override
        public SimpleLinkedIndividual copy(){
            return new SimpleLinkedIndividual( this);
        }

        @Override
        public boolean equals(Object o) { // true if object properties & super (= ontoRef, instance, types) are equals
            if (this == o) return true;
            if (!(o instanceof SimpleLinkedIndividual)) return false;
            if (!super.equals(o)) return false;

            SimpleLinkedIndividual that = (SimpleLinkedIndividual) o;

            boolean v = linkingMap != null ? linkingMap.equals(that.linkingMap) : that.linkingMap == null;
            return v & super.equals( o);
        }
        @Override
        public int hashCode() {
            int result = super.hashCode();
            result = 31 * result + (linkingMap != null ? linkingMap.hashCode() : 0);
            return result;
        }

        @Override
        public String toString() {
            return super.toString() + getStringfixedLength( " with object properties: ", LOGGING_LONG_NUMBER_LENGTH, true)
                    + linkingMap;
        }
    }
}
