package it.emarolab.scene_identification_tracking.semanticSceneLibrary.old.core.aMORDescriptor;

import it.emarolab.amor.owlInterface.OWLReferences;
import org.semanticweb.owlapi.model.*;

import java.util.*;

/**
 * Created by bubx on 18/01/17.
 */// todo add MORDescriptor
public interface MORFullInstanceDescriptor extends
        MORTypedIndividualDescriptor, MORLinkedIndividualDescriptor, MORLinkedDataDescriptor{

    @Override
    MORFullInstanceDescriptor copy();

    class MORSimpleFullInstanceDescriptor extends MORTypedIndividualDescriptor.SimpleTypedIndividual
            implements MORFullInstanceDescriptor {

        private LinkedHashMap<OWLDataProperty, OWLLiteral> linkingDataMap = new LinkedHashMap<>();
        private LinkedHashMap<OWLObjectProperty, OWLNamedIndividual> linkingObjectMap = new LinkedHashMap<>();

        public MORSimpleFullInstanceDescriptor(MORSimpleFullInstanceDescriptor copy) {
            super(copy);
            this.linkingDataMap = new LinkedHashMap<>( copy.linkingDataMap);
            this.linkingObjectMap = new LinkedHashMap<>( copy.linkingObjectMap);
        }

        public MORSimpleFullInstanceDescriptor(String ontoRef, String individual, String type) {
            super(ontoRef, individual, type);
        }
        public MORSimpleFullInstanceDescriptor(OWLClass type) {
            super(type);
        }
        public MORSimpleFullInstanceDescriptor(String ontoRef, OWLClass type) {
            super(ontoRef, type);
        }
        public MORSimpleFullInstanceDescriptor(OWLReferences ontoRef, OWLClass type) {
            super(ontoRef, type);
        }
        public MORSimpleFullInstanceDescriptor(OWLNamedIndividual instance, OWLClass type) {
            super(instance, type);
        }
        public MORSimpleFullInstanceDescriptor(String ontoRef, String individual, OWLClass type) {
            super(ontoRef, individual, type);
        }
        public MORSimpleFullInstanceDescriptor(OWLReferences ontoRef, OWLNamedIndividual individual, OWLClass type) {
            super(ontoRef, individual, type);
        }
        public MORSimpleFullInstanceDescriptor(Collection<?> types) {
            super(types);
        }
        public MORSimpleFullInstanceDescriptor(String ontoRef, Collection<?> types) {
            super(ontoRef, types);
        }
        public MORSimpleFullInstanceDescriptor(OWLReferences ontoRef, Collection<?> types) {
            super(ontoRef, types);
        }
        public MORSimpleFullInstanceDescriptor(OWLNamedIndividual ontoRef, Collection<?> types) {
            super(ontoRef, types);
        }
        public MORSimpleFullInstanceDescriptor(String ontoRef, String individual, Collection<?> types) {
            super(ontoRef, individual, types);
        }
        public MORSimpleFullInstanceDescriptor(OWLReferences ontoRef, OWLNamedIndividual individual, Collection<?> types) {
            super(ontoRef, individual, types);
        }

        @Override
        public LinkedHashMap<OWLDataProperty, OWLLiteral> getLinkedLiteral() {
            return linkingDataMap;
        }

        @Override
        public LinkedHashMap<OWLObjectProperty, OWLNamedIndividual> getLinkedInstance() {
            return linkingObjectMap;
        }

        @Override
        public MORSimpleFullInstanceDescriptor copy() {
            return new MORSimpleFullInstanceDescriptor( this);
        }

        @Override
        public boolean equals(Object o) {
            if (this == o) return true;
            if (!(o instanceof MORSimpleFullInstanceDescriptor)) return false;
            if (!super.equals(o)) return false;

            MORSimpleFullInstanceDescriptor that = (MORSimpleFullInstanceDescriptor) o;

            if (linkingDataMap != null ? !linkingDataMap.equals(that.linkingDataMap) : that.linkingDataMap != null)
                return false;
            boolean v = linkingObjectMap != null ? linkingObjectMap.equals(that.linkingObjectMap) : that.linkingObjectMap == null;
            return v & super.equals( o);
        }
        @Override
        public int hashCode() {
            int result = super.hashCode();
            result = 31 * result + (linkingDataMap != null ? linkingDataMap.hashCode() : 0);
            result = 31 * result + (linkingObjectMap != null ? linkingObjectMap.hashCode() : 0);
            return result;
        }

        @Override
        public String toString() {
            return super.toString()
                    + getStringfixedLength( " with object properties: ", LOGGING_LONG_NUMBER_LENGTH, true)
                    + linkingObjectMap
                    + getStringfixedLength( " and data properties: ", LOGGING_LONG_NUMBER_LENGTH, true)
                    + linkingDataMap;
        }

//implements SpatialDescriptor.SpatialSemantics< OWLReferences, OWLNamedIndividual, OWLClass,
        //                                                                 OWLDataProperty, OWLObjectProperty, OWLLiteral> {

        // !!    REMARK     !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
        // !! move OWL named instance in a new 'OWLDescriptor' class and extend MoRDescription with it.            !!
        // !!!this improves compatibility with tracker by changing the parameter of the trackeing object class to:   !!
        // see SemanticObjectItem< OWLDescription>                                                                !!
        // !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!

//        // internal fields
//        private String individualName;
//        private String ontologyName = null;
//        private OWLReferences ontology;
//        private OWLNamedIndividual instance;
//        private List< OWLClass> types; // todo comment, setter and getter
//
//        /**
//         * Cloning constructor, create a new object as a clone of the input parameter.
//         * @param descriptor the object to clone.
//         */
//        public MORSimpleFullInstanceDescriptor(MORSimpleFullInstanceDescriptor descriptor){
//            this.individualName = descriptor.individualName;
//            this.ontology = descriptor.ontology;
//            this.ontologyName = descriptor.ontologyName;
//            this.individualName = descriptor.individualName;
//            this.types = new ArrayList<>( descriptor.types);
//        }
//        /**
//         * Construct this object by assigning the name of the instance.
//         * It does not assign any OWLReferences to this object.
//         * @param individualName the name of the OWL instance describe the
//         *                       semantic object related to this descriptor.
//         */
//        public MORSimpleFullInstanceDescriptor(String individualName) {
//            this.individualName = individualName;
//            this.types = new ArrayList<>();
//        }
//        public MORSimpleFullInstanceDescriptor(OWLNamedIndividual individual, OWLReferences ontoRef) { // todo add on extending constructors
//            this.ontologyName = ontoRef.getReferenceName();
//            this.ontology = ontoRef;
//            this.instance = individual;
//            this.individualName = ontoRef.getOWLObjectName( individual);
//            this.types = new ArrayList<>();
//        }
//        /**
//         * Fully construct the descriptor of the semantic of the object.
//         * @param individualName the name of the OWL instance describe the
//         *                       semantic object related to this descriptor.
//         * @param ontoName the name an instantiated {@link OWLReferences} linked to the
//         *                 ontology describing this object.
//         */
//        public MORSimpleFullInstanceDescriptor(String individualName, String ontoName) {
//            this.individualName = individualName;
//            setOntology( ontoName);
//            this.types = new ArrayList<>();
//        }
//
//
//        @Override
//        public boolean addType(OWLClass toAdd){
//            return types.add( toAdd);
//        }
//        @Override
//        public boolean removeType(OWLClass toRemove){
//            return types.remove( toRemove);
//        }
//        @Override
//        public boolean containsTypes(OWLClass toCheck){
//            return types.contains( toCheck);
//        }
//
//
//        @Override
//        public void setOntologyName(String referenceName) {
//            OWLReferences ref = (OWLReferences) OWLReferencesInterface.OWLReferencesContainer.getOWLReferences( referenceName);
//            if( ref != null) {
//                this.ontology = ref;
//                this.ontologyName = referenceName;
//            } else SITBase.logERROR( "MORDescriptor cannot set an not instanced OWLReference by name: " + referenceName);
//        }
//
//        @Override
//        public void setIndividualName(String individualName) {
//            if( individualName != null){
//                this.individualName = individualName;
//                if( getOntology() != null)
//                    this.instance = this.getOntology().getOWLIndividual( individualName);
//                else SITBase.logWARNING( "MORDescriptor update instance name to " + individualName + ". " +
//                        "But it cannot create a new individual since OWLReference is null.");
//            } else SITBase.logERROR( "MORDescriptor cannot change the individual name to 'null'");
//        }
//
//        @Override
//        public List<OWLClass> getTypes() {
//            return this.types;
//        }
//
//        @Override
//        public void setType(List<OWLClass> types) {
//            this.types = types;
//        }
//
//        @Override
//        public String getIndividualName() {
//            return this.individualName;
//        }
//
//        @Override
//        public String getOntologyName() {
//            return this.ontologyName;
//        }
//
//        @Override
//        public MORSimpleFullInstanceDescriptor copy() {
//            return new MORSimpleFullInstanceDescriptor( this);
//        }
//
//        @Override
//        public OWLReferences getOntology() {
//            return this.ontology;
//        }
//
//        @Override
//        public OWLNamedIndividual getInstance() {
//            return this.instance;
//        }
//
//        @Override
//        public void setOntology(OWLReferences ontology)  {
//            this.ontology = ontology;
//            this.setOntologyName( ontology.getReferenceName());
//            this.setInstance( getInitialIndividual());
//        }
//
//        @Override
//        public void setInstance(OWLNamedIndividual instance) {
//            this.instance = instance;
//        }
    }




//
//// todo move Try away
//    /**
//     * This is an helper based on {@link Logger.MappingTry} for semantic mpping based on aMORObject library.
//     * <p>
//     * It also implements helper methods to deal with {@link OWLDataProperty},
//     * and {@link OWLLiteral} by using the aMORObject library.
//     *
//     * <div style="text-align:center;"><small>
//     * <b>File</b>:       it.emarolab.scene_identification_tracking.semanticSceneLibrary.old.core.Semantics <br>
//     * <b>Licence</b>:    GNU GENERAL PUBLIC LICENSE. Version 3, 29 June 2007 <br>
//     * <b>Author</b>:     Buoncompagni Luca (luca.buoncompagni@edu.unige.it) <br>
//     * <b>affiliation</b>: DIBRIS, EMAROLab, University of Genoa. <br>
//     * <b>date</b>:       06/01/2017 <br>
//     * </small></div>
//     *
//     * @param <Y> the class that define the {@link Semantics.MappingState}
//     *           (i.e.: {@link Semantics.ReadingState} or {@link Semantics.WritingState}).
//     *
//     * @see Logger.MappingTry
//     * @see Semantics.MappingState
//     * @see Semantics.WritingState
//     * @see Semantics.ReadingState
//     * @see DataSemanticChange
//     * @see TryingWrite
//     * @see TryingRead
//     */
//    abstract class MappingTry< Y extends Semantics.MappingState> extends Logger.MappingTry< Y> {
//        /** the ontology given on constructor. Directly accessible from extending implementations. */
//        protected final OWLReferences ontology;
//        /** the name of the #OWLReferences given on constructor. Directly accessible from extending implementations. */
//        protected final String ontologyName;
//        /** the instance in the ontology given on constructor. Directly accessible from extending implementations. */
//        protected final OWLNamedIndividual individual;
//        /** the name of the #OWLNamedIndividual given on constructor. Directly accessible from extending implementations. */
//        protected final String individualName;
//
//        /**
//         * Construct by filling all internal fields with an <code>final</code> value.
//         * @param semantic the description of the ontology ({@link MORSpatialInstanceDescriptorFullInstance.MORSimpleSpatialInstanceDescriptorFullInstance#getOntology()})
//         *                  and of the instance ({@link MORSpatialInstanceDescriptorFullInstance.MORSimpleSpatialInstanceDescriptorFullInstance#getInstance()},
//         *                  {@link MORSpatialInstanceDescriptorFullInstance.MORSimpleSpatialInstanceDescriptorFullInstance#getIndividualName()})
//         */
//        public MappingTry(MORFullInstanceDescriptor semantic) {
//            ontology = semantic.getOntology();
//            ontologyName = ontology.getReferenceName();
//            individual = semantic.getInstance();
//            individualName = semantic.getIndividualName();
//        }
//
//        /**
//         * Called on {@link #perform()} if an {@link openllet.owlapi.OWLException} occurs.
//         * @return an {@link Semantics.MappingState#INCONSISTENT}
//         * state due to an OWL Exception during the semantic mapaping process.
//         */
//        abstract  protected Y onOWLException();
//
//        /**
//         * @return the state of this mapping operation. It can be the
//         * {@link #giveAtry()} returning value, the {@link #onError()},
//         * if Java {@link Exception} occurs (logged through {@link #logError(Exception)}).
//         * Otherwise, il an {@link openllet.owlapi.OWLException} occurs, it returns calls
//         * {@link #onOWLException()} and returns its value.
//         */
//        @Override
//        public Y perform() {
//            try {
//                return giveAtry();
//            } catch (openllet.owlapi.OWLException e){
//                logError( e);
//                return onOWLException();
//            } catch (Exception e) {
//                logError( e);
//                return onError();
//            }
//        }
//
//        /**
//         * @param propertyName the name of the OWL data property to be used to retrieve the literal.
//         * @return the literal of a OWL data property (given by name) evaluated with
//         * respect to the {@link #individual} of the {@link #ontology}.
//         */
//        public OWLLiteral getPropertyData( String propertyName){
//            OWLDataProperty prop = ontology.getOWLDataProperty( propertyName);
//            return getPropertyData( prop);
//        }
//        /**
//         * @param property the OWL data property to be used to retrieve the literal.
//         * @return the literal of a OWL data property evaluated with
//         * respect to the {@link #individual} of the {@link #ontology}.
//         */
//        public OWLLiteral getPropertyData(OWLDataProperty property){
//            return ontology.getOnlyDataPropertyB2Individual( individual, property);
//        }
//
//        public OWLNamedIndividual getPropertyObject( String propertyName){
//            OWLObjectProperty prop = ontology.getOWLObjectProperty( propertyName);
//            return getPropertyObject( prop);
//        }
//        public OWLNamedIndividual getPropertyObject(OWLObjectProperty property){
//            return ontology.getOnlyObjectPropertyB2Individual( individual, property);
//        }
//
//        /**
//         * @param propertyName the name of the OWL data property to be used to retrieve the value.
//         * @return the {@link Double} value of a OWL data property evaluated with
//         * respect to the {@link #individual} of the {@link #ontology}.
//         */
//        public Double getDoublePropertyValue(String propertyName) {
//            OWLDataProperty prop = ontology.getOWLDataProperty( propertyName);
//            return getDoublePropertyValue( prop);
//        }
//        /**
//         * @param property the OWL data property to be used to retrieve the value.
//         * @return the {@link Double} value of a OWL data property evaluated with
//         * respect to the {@link #individual} of the {@link #ontology}.
//         */
//        public Double getDoublePropertyValue(OWLDataProperty property) {
//            OWLLiteral l = getPropertyData( property);
//            if ( l == null)
//                return null;
//            return Double.valueOf(l.getLiteral());
//        }
//
//        /**
//         * @param propertyName the name of the OWL data property to be used to retrieve the value.
//         * @return the {@link Long} value of a OWL data property evaluated with
//         * respect to the {@link #individual} of the {@link #ontology}.
//         */
//        public Long getLongPropertyValue(String propertyName) {
//            OWLDataProperty prop = ontology.getOWLDataProperty( propertyName);
//            return getLongPropertyValue( prop);
//        }
//        /**
//         * @param property the OWL data property to be used to retrieve the value.
//         * @return the {@link Long} value of a OWL data property evaluated with
//         * respect to the {@link #individual} of the {@link #ontology}.
//         */
//        public Long getLongPropertyValue(OWLDataProperty property) {
//            OWLLiteral l = getPropertyData( property);
//            if ( l == null)
//                return null;
//            return Long.valueOf(l.getLiteral());
//        }
//
//        /**
//         * @param propertyName the name of the OWL data property to be used to retrieve the value.
//         * @return the {@link String} value of a OWL data property evaluated with
//         * respect to the {@link #individual} of the {@link #ontology}.
//         */
//        public String getStringPropertyValue(String propertyName) {
//            OWLDataProperty prop = ontology.getOWLDataProperty( propertyName);
//            return getStringPropertyValue( prop);
//        }
//        /**
//         * @param property the OWL data property to be used to retrieve the value.
//         * @return the {@link String} value of a OWL data property evaluated with
//         * respect to the {@link #individual} of the {@link #ontology}.
//         */
//        public String getStringPropertyValue(OWLDataProperty property) {
//            OWLLiteral l = getPropertyData( property);
//            if ( l == null)
//                return null;
//            return String.valueOf(l.getLiteral());
//        }
//
//        /**
//         * @param propertyName the name of the OWL data property to be used to retrieve the value.
//         * @return the {@link Float} value of a OWL data property evaluated with
//         * respect to the {@link #individual} of the {@link #ontology}.
//         */
//        public Float getFloatPropertyValue(String propertyName) {
//            OWLDataProperty prop = ontology.getOWLDataProperty( propertyName);
//            return getFloatPropertyValue( prop);
//        }
//        /**
//         * @param property the OWL data property to be used to retrieve the value.
//         * @return the {@link Float} value of a OWL data property evaluated with
//         * respect to the {@link #individual} of the {@link #ontology}.
//         */
//        public Float getFloatPropertyValue(OWLDataProperty property) {
//            OWLLiteral l = getPropertyData( property);
//            if ( l == null)
//                return null;
//            return Float.valueOf(l.getLiteral());
//        }
//
//        /** @return the aMORObject ontology reference given on constructor. */
//        public OWLReferences getOntology() {
//            return ontology;
//        }
//        /** @return the aMORObject ontology reference name given on constructor. */
//        public String getOntologyName() {
//            return ontologyName;
//        }
//        /** @return the OWL instance of the {@link #ontology} given on constructor. */
//        public OWLNamedIndividual getIndividual() {
//            return individual;
//        }
//        /** @return the OWL instance name of the {@link #ontology} given on constructor. */
//        public String getIndividualName() {
//            return individualName;
//        }
//    }
//    /**
//     * The {@link MORSpatialInstanceDescriptorFullInstance.MORSimpleSpatialInstanceDescriptorFullInstance.MappingTry} implementation for reading operations ({@link Semantics.ReadingState}).
//     *
//     * <div style="text-align:center;"><small>
//     * <b>File</b>:       it.emarolab.scene_identification_tracking.semanticSceneLibrary.old.core.Semantics <br>
//     * <b>Licence</b>:    GNU GENERAL PUBLIC LICENSE. Version 3, 29 June 2007 <br>
//     * <b>Author</b>:     Buoncompagni Luca (luca.buoncompagni@edu.unige.it) <br>
//     * <b>affiliation</b>: DIBRIS, EMAROLab, University of Genoa. <br>
//     * <b>date</b>:       06/01/2017 <br>
//     * </small></div>
//     *
//     * @see MORSpatialInstanceDescriptorFullInstance.MORSimpleSpatialInstanceDescriptorFullInstance.MappingTry
//     * @see Semantics.ReadingState
//     */
//    abstract class TryingRead extends MappingTry<Semantics.ReadingState> {
//
//        /**
//         * Empty constructor based on {@link MORSpatialInstanceDescriptorFullInstance.MORSimpleSpatialInstanceDescriptorFullInstance.MappingTry#MappingTry(MORSpatialInstanceDescriptorFullInstance.MORSimpleSpatialInstanceDescriptorFullInstance)}.
//         * @param semantic the aMORObject based description of the ontology
//         *                  and instance used during semantic mapping.
//         */
//        public TryingRead(MORFullInstanceDescriptor semantic) {
//            super(semantic);
//        }
//
//        /**
//         * @param r1 the first reading process state to be merged.
//         * @param r2 the second reading process state to be merged
//         * @return the reading process state based on the input parameters.
//         * Indeed, it calls {@link Semantics.ReadingState#combineResults(Semantics.ReadingState, Semantics.ReadingState)}.
//         */
//        protected Semantics.ReadingState merge(Semantics.ReadingState r1, Semantics.ReadingState r2) {
//            return Semantics.ReadingState.combineResults(r1, r2);
//        }
//
//        @Override
//        protected Semantics.ReadingState onOWLException(){
//            return new Semantics.ReadingState().asInconsistent();
//        }
//
//        @Override
//        protected Semantics.ReadingState onError(){
//            return new Semantics.ReadingState().asError();
//        }
//    }
//    /**
//     * The {@link MORSpatialInstanceDescriptorFullInstance.MORSimpleSpatialInstanceDescriptorFullInstance.MappingTry} implementation for writing operations ({@link Semantics.WritingState}).
//     *
//     * <div style="text-align:center;"><small>
//     * <b>File</b>:       it.emarolab.scene_identification_tracking.semanticSceneLibrary.old.core.Semantics <br>
//     * <b>Licence</b>:    GNU GENERAL PUBLIC LICENSE. Version 3, 29 June 2007 <br>
//     * <b>Author</b>:     Buoncompagni Luca (luca.buoncompagni@edu.unige.it) <br>
//     * <b>affiliation</b>: DIBRIS, EMAROLab, University of Genoa. <br>
//     * <b>date</b>:       06/01/2017 <br>
//     * </small></div>
//     *
//     * @see MappingTry
//     * @see Semantics.WritingState
//     */
//    abstract class TryingWrite extends MappingTry<Semantics.WritingState> {
//
//        /**
//         * Empty constructor based on {@link MORSpatialInstanceDescriptorFullInstance.MORSimpleSpatialInstanceDescriptorFullInstance.MappingTry#MappingTry(MORSpatialInstanceDescriptorFullInstance.MORSimpleSpatialInstanceDescriptorFullInstance)}.
//         * @param semantic the aMORObject based description of the ontology
//         *                  and instance used during semantic mapping.
//         */
//        public TryingWrite(MORFullInstanceDescriptor semantic) {
//            super(semantic);
//        }
//
//        /**
//         * @param r1 the first writing process state to be merged.
//         * @param r2 the second writing process state to be merged
//         * @return the writing process state based on the input parameters.
//         * Indeed, it calls {@link Semantics.WritingState#combineResults(Semantics.WritingState, Semantics.WritingState)}.
//         */
//        protected Semantics.WritingState merge(Semantics.WritingState r1, Semantics.WritingState r2) {
//            return Semantics.WritingState.combineResults( r1, r2);
//        }
//
//        @Override
//        protected Semantics.WritingState onOWLException(){
//            return new Semantics.WritingState().asInconsistent();
//        }
//
//        @Override
//        protected Semantics.WritingState onError(){
//            return new Semantics.WritingState().asError();
//        }
//    }
//
//
//    /**
//     * A container for reading results.
//     * <p>
//     *     It implements an extension of {@link Semantics.SemanticChange} by
//     *     specifying the type of the reading buffer as {@link OWLLiteral}.
//     *
//     * <div style="text-align:center;"><small>
//     * <b>File</b>:       it.emarolab.scene_identification_tracking.semanticSceneLibrary.old.core.Semantics <br>
//     * <b>Licence</b>:    GNU GENERAL PUBLIC LICENSE. Version 3, 29 June 2007 <br>
//     * <b>Author</b>:     Buoncompagni Luca (luca.buoncompagni@edu.unige.it) <br>
//     * <b>affiliation</b>: DIBRIS, EMAROLab, University of Genoa. <br>
//     * <b>date</b>:       06/01/2017 <br>
//     * </small></div>
//     *
//     * @see MORSpatialInstanceDescriptorFullInstance.MORSimpleSpatialInstanceDescriptorFullInstance
//     * @see Semantics.SemanticChange
//     */
//    class DataSemanticChange extends Semantics.SemanticChange<OWLLiteral> {
//        /**
//         * Empty constructor, set null buffer and inconsistent reading stet
//         * Indeed it calls {@link Semantics.SemanticChange#SemanticChange()}.
//         */
//        public DataSemanticChange(){
//            super();
//        }
//        /**
//         * Construct by specifying all the fields of this container.
//         * Indeed it calls {@link Semantics.SemanticChange#ReadingOutcome(Object, Semantics.ReadingState)}).
//         * @param readBuffer the value read from the ontology.
//         * @param results the result of the reading process.
//         */
//        public DataSemanticChange(OWLLiteral readBuffer, Semantics.ReadingState results) {
//            super( readBuffer, results);
//        }
//
//        /**  @return the value of {@link OWLLiteral} available in the reading buffere as a {@link Double}.*/
//        public Double getDoubleReadBuffer(){
//            if( getReadBuffer() == null)
//                return null;
//            return Double.valueOf( getReadBuffer().getLiteral());
//        }
//        /**  @return the value of {@link OWLLiteral} available in the reading buffere as a {@link String}.*/
//        public String getStringReadBuffer(){
//            if( getReadBuffer() == null)
//                return null;
//            return String.valueOf( getReadBuffer().getLiteral());
//        }
//        /**  @return the value of {@link OWLLiteral} available in the reading buffere as a {@link Long}.*/
//        public Long getLongReadBuffer(){
//            if( getReadBuffer() == null)
//                return null;
//            return Long.valueOf( getReadBuffer().getLiteral());
//        }
//        /**  @return the value of {@link OWLLiteral} available in the reading buffere as a {@link Float}.*/
//        public Float getFloatReadBuffer(){
//            if( getReadBuffer() == null)
//                return null;
//            return Float.valueOf( getReadBuffer().getLiteral());
//        }
//
//        /**
//         * Based on {@link Semantics.ReadingState#merge(Semantics.ReadingState)}, it
//         * combine two reading states in one.
//         * @param otherResult the state of a reading operation to be merges with <code>this.{@link #getState()}</code>.
//         * @return <code>this</code>, for chaining calls
//         */
//        @Override
//        public DataSemanticChange merge(Semantics.ReadingState otherResult){
//            this.getState().merge( otherResult);
//            return this;
//        }
//
//        /**
//         * Based on {@link Semantics.ReadingState#merge(Semantics.ReadingState)}, it
//         * combine two reading states in one.
//         * @param otherResult the outcome containing the state ({@link #getState()})
//         *                    of a reading operation to be merged with <code>this.{@link #getState()}</code>.
//         * @return <code>this</code>, for chaining calls
//         */
//        public DataSemanticChange merge(DataSemanticChange otherResult){
//            this.merge( otherResult.getState());
//            return this;
//        }
//    }
//    class ObjectSemanticChange extends Semantics.SemanticChange<OWLNamedIndividual> {
//        /**
//         * Empty constructor, set null buffer and inconsistent reading stet
//         * Indeed it calls {@link Semantics.SemanticChange#SemanticChange()}.
//         */
//        public ObjectSemanticChange(){
//            super();
//        }
//        /**
//         * Construct by specifying all the fields of this container.
//         * Indeed it calls {@link Semantics.SemanticChange#ReadingOutcome(Object, Semantics.ReadingState)}).
//         * @param readBuffer the value read from the ontology.
//         * @param results the result of the reading process.
//         */
//        public ObjectSemanticChange(OWLNamedIndividual readBuffer, Semantics.ReadingState results) {
//            super( readBuffer, results);
//        }
//
//        /**
//         * Based on {@link Semantics.ReadingState#merge(Semantics.ReadingState)}, it
//         * combine two reading states in one.
//         * @param otherResult the state of a reading operation to be merges with <code>this.{@link #getState()}</code>.
//         * @return <code>this</code>, for chaining calls
//         */
//        @Override
//        public ObjectSemanticChange merge(Semantics.ReadingState otherResult){
//            this.getState().merge( otherResult);
//            return this;
//        }
//
//        /**
//         * Based on {@link Semantics.ReadingState#merge(Semantics.ReadingState)}, it
//         * combine two reading states in one.
//         * @param otherResult the outcome containing the state ({@link #getState()})
//         *                    of a reading operation to be merged with <code>this.{@link #getState()}</code>.
//         * @return <code>this</code>, for chaining calls
//         */
//        public ObjectSemanticChange merge(ObjectSemanticChange otherResult){
//            this.merge( otherResult.getState());
//            return this;
//        }
//    }
//    class TypeSemanticChange extends Semantics.SemanticChange< List< OWLClass>> {
//        /**
//         * Empty constructor, set null buffer and inconsistent reading stet
//         * Indeed it calls {@link Semantics.SemanticChange#SemanticChange()}.
//         */
//        public TypeSemanticChange(){
//            super();
//        }
//        /**
//         * Construct by specifying all the fields of this container.
//         * Indeed it calls {@link Semantics.SemanticChange#ReadingOutcome(Object, Semantics.ReadingState)}).
//         * @param readBuffer the value read from the ontology.
//         * @param results the result of the reading process.
//         */
//        public TypeSemanticChange(List< OWLClass> readBuffer, Semantics.ReadingState results) {
//            super( readBuffer, results);
//        }
//
//        /**
//         * Based on {@link Semantics.ReadingState#merge(Semantics.ReadingState)}, it
//         * combine two reading states in one.
//         * @param otherResult the state of a reading operation to be merges with <code>this.{@link #getState()}</code>.
//         * @return <code>this</code>, for chaining calls
//         */
//        @Override
//        public TypeSemanticChange merge(Semantics.ReadingState otherResult){
//            this.getState().merge( otherResult);
//            return this;
//        }
//
//        /**
//         * Based on {@link Semantics.ReadingState#merge(Semantics.ReadingState)}, it
//         * combine two reading states in one.
//         * @param otherResult the outcome containing the state ({@link #getState()})
//         *                    of a reading operation to be merged with <code>this.{@link #getState()}</code>.
//         * @return <code>this</code>, for chaining calls
//         */
//        public TypeSemanticChange merge(TypeSemanticChange otherResult){
//            this.merge( otherResult.getState());
//            return this;
//        }
//    }
//




























//
//
//    //Semantics.FullInstanceDescriptor< OWLReferences, OWLNamedIndividual, OWLClass, OWLDataProperty, OWLObjectProperty, OWLLiteral> {
//
//    void setOntology(OWLReferences ontoRef);
//
//    void setOntologyName(String referenceName);
//    void setIndividualName(String individualName);
//
//
//    default OWLNamedIndividual getInitialIndividual(){ // todo not in the interface ????
//        if( getIndividualName() != null)
//            return getOntology().getOWLIndividual( getIndividualName());
//        else Logger.SITBase.logWARNING( this.getClass().getName() + ".setOntology() " +
//                "did not create any instance [null] !!!");
//        return null;
//    }
//
//
//
//    // todo check copy()
//
//    String getIndividualName();
//    String getOntologyName();
//
//
//
//    default OWLClass getType(int idx){
//        return getTypes().get( idx);
//    }
//
//    default OWLClass getHighestType(){
//        return getType( getTypes().size() - 1);
//    }
//
//    /**
//     * It uses the {@link MORSpatialInstanceDescriptorFullInstance.MORSimpleSpatialInstanceDescriptorFullInstance.TryingWrite#perform()} interface for synchronise a
//     * javaValue (the value of an {@link OWLDataProperty}) from a java representation
//     * (the object related to this descriptor) into the {@link #getOntology()}
//     * (indeed the value will be written to: {@link #getInstance()}).
//     * <p>
//     *     In particular, it:
//     *     <ul>
//     *        <li> reads the value of a property and, if it does not exists,
//     *             it creates a new axiom in the ontology by mapping a java representation.
//     *             In this case it returns an {@link Semantics.WritingState#ADDED} state.
//     *        <li> otherwise, if the value of the previous point exists.
//     *             It checks if it is <code>semanticLiteral.equals( javaValue)</code> to the java representation.
//     *             If their are not equal, it does not perform any ontological changes and returns
//     *             a {@link Semantics.WritingState#NOT_CHANGED} state.
//     *        <li> If it is not the case, it synchronise the OWL ontology with respect to
//     *             the java representation and returns an {@link Semantics.WritingState#UPDATED} state.
//     *     </ul>
//     * <p>
//     *     <b>REMARK</b>: the first point check for a value relate to a semantic data
//     *     property. If the same instance has more than one value for the same property
//     *     this implementation does not assure any rule on the used value.
//     *
//     * @param debuggingInfo a string used for debugging logging.
//     * @param property the OWL data property to be used to semantically write a value to an instance
//     * @param javaValue the javaValue to be mapped in the instance (in the ontology) defined by this descriptor.
//     * @return the state of the writing of a OWL data property value.
//     *
//     * @see MORSpatialInstanceDescriptorFullInstance.MORSimpleSpatialInstanceDescriptorFullInstance.TryingWrite
//     */
//    default Semantics.WritingState writeLiteral(String debuggingInfo, OWLDataProperty property, OWLLiteral javaValue){
//        return new MORSpatialInstanceDescriptorFullInstance.MORSimpleSpatialInstanceDescriptorFullInstance.TryingWrite( this) {
//            protected Semantics.WritingState giveAtry() {
//                // see around
//                Semantics.WritingState result;
//                OWLLiteral semanticLiteral = getPropertyData( property);
//                // adding
//                if( semanticLiteral == null) {
//                    ontology.addDataPropertyB2Individual( individual, property, javaValue);
//                    result = new Semantics.WritingState().asAdded();
//                } else if( ! semanticLiteral.equals( javaValue)){ // replacing
//                    ontology.replaceDataProperty( individual, property, semanticLiteral, javaValue);
//                    result = new Semantics.WritingState().asUpdated();
//                } else result = new Semantics.WritingState().asNotChanged(); // nothing
//
//                log( this.getClass().getSimpleName() + "\t WRITES LITERAL: \"" + individualName
//                        + "\"(" + debuggingInfo + ")"
//                        + "\t\t " + getOntology().getOWLObjectName( property) + "." + getOntology().getOWLObjectName(semanticLiteral)
//                        + "\t(was in ontology: " + getOntology().getOWLObjectName(semanticLiteral) + ")"
//                        + "\t\t[" + result + "]");
//                return result;
//            }
//        }.perform();
//    }
//    /**
//     * It uses the {@link MORSpatialInstanceDescriptorFullInstance.MORSimpleSpatialInstanceDescriptorFullInstance.TryingRead#perform()} interface for synchronise a
//     * java representation (the object related to this descriptor) from a literal
//     * (the oldJavaValue of an {@link OWLDataProperty}) into the {@link #getOntology()}
//     * (indeed the oldJavaValue will be written to: {@link #getInstance()}).
//     * <p>
//     *     In particular, it:
//     *     <ul>
//     *        <li> reads the oldJavaValue of a property and, if it does not exists,
//     *             In this case it returns an {@link Semantics.ReadingState#ABSENT} state
//     *             through the {@link DataSemanticChange} container (reading buffer will be set to <code>null</code>).
//     *        <li> otherwise, if the oldJavaValue of the previous point exists.
//     *             It checks if it is <code>semanticValue.equals( oldJavaValue)</code> to the java representation.
//     *             If it is the case, it does not perform any changes in the java description and returns
//     *             a {@link Semantics.WritingState#NOT_CHANGED} state (though {@link DataSemanticChange}
//     *             with the oldJavaValue get from the ontology in the buffer).
//     *        <li> If their are not equal, it synchronise the java representation with the
//     *             oldJavaValue read from the OWL ontology and returns an {@link Semantics.WritingState#UPDATED} state.
//     *     </ul>
//     *
//     * @param debuggingInfo a string used for debugging logging.
//     * @param property the OWL data property to be used to semantically read the oldJavaValue from the instance
//     * @param oldJavaValue the oldJavaValue to be mapped in the java representation from the ontology.
//     * @return the state of the reading of an OWL data property oldJavaValue.
//     *
//     * @see MORSpatialInstanceDescriptorFullInstance.MORSimpleSpatialInstanceDescriptorFullInstance.TryingRead
//     * @see DataSemanticChange
//     */
//    default DataSemanticChange readLinkedLiteral(String debuggingInfo, OWLDataProperty property, OWLLiteral oldJavaValue){
//        final DataSemanticChange outcomes = new DataSemanticChange();
//        new MORSpatialInstanceDescriptorFullInstance.MORSimpleSpatialInstanceDescriptorFullInstance.TryingRead( this) {
//            @Override
//            protected Semantics.ReadingState giveAtry() {
//                // see around
//                Semantics.ReadingState result;
//                OWLLiteral semanticValue = getPropertyData( property);
//                if( semanticValue == null) // does not exist
//                    result = new Semantics.ReadingState().asAbsent();
//                else if( semanticValue.equals( oldJavaValue)) // it was up to date
//                    result = new Semantics.ReadingState().asNotChanged();
//                else result = new Semantics.ReadingState().asSuccess(); // it has been loaded
//                log( this.getClass().getSimpleName() + "\t READS LITERAL: \"" + individualName
//                        + "\"(" + debuggingInfo + ")"
//                        + "\t\t " + getOntology().getOWLObjectName( property) + "." + getOntology().getOWLObjectName( semanticValue)
//                        + "\t(was in java: " + getOntology().getOWLObjectName(oldJavaValue) + ")"
//                        + "\t\t[" + result + "]");
//                outcomes.setReadBuffer( semanticValue, result);
//                return result;
//            }
//        }.perform();
//        return outcomes;
//    }

}
