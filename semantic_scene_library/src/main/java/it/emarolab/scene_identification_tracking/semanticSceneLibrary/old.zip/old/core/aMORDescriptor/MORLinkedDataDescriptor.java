package it.emarolab.scene_identification_tracking.semanticSceneLibrary.old.core.aMORDescriptor;

import it.emarolab.amor.owlInterface.OWLReferences;
import it.emarolab.scene_identification_tracking.semanticSceneLibrary.old.Logger;
import it.emarolab.scene_identification_tracking.semanticSceneLibrary.old.core.Semantics;
import org.semanticweb.owlapi.model.*;

import java.util.*;

public interface MORLinkedDataDescriptor extends MORDescriptor.MORIndividualDescriptor,
        Semantics.LinkedDataDescriptor<OWLReferences, OWLNamedIndividual, OWLDataProperty, OWLLiteral> {

    @Override
    LinkedHashMap<OWLDataProperty, OWLLiteral> getLinkedLiteral();

    default void clearLinekdLiteral(){
        getLinkedLiteral().clear();
    }

    default List< OWLDataProperty> getAllLinksLiteral(){
        List< OWLDataProperty> out = new ArrayList<>();
        for ( OWLDataProperty o : getLinkedLiteral().keySet())
            out.add( o);
        return out;
    }
    default List< OWLLiteral> getAllLinkedLiteral(){
        List< OWLLiteral> out = new ArrayList<>();
        for ( OWLDataProperty o : getLinkedLiteral().keySet())
            out.add( getLinkedLiteral( o));
        return out;
    }

    default void linkLiteral(OWLDataProperty property){
        getLinkedLiteral().put( property, null);
    }
    default void linkLiteral(String propertyName){
        OWLDataProperty property = getOntology().getOWLDataProperty( propertyName);
        linkLiteral( property);
    }

    default void linkLiteral(OWLDataProperty property, OWLLiteral literal){
        getLinkedLiteral().put(property, literal);
    }
    default void linkLiteral(String propertyName, Object obj){
        OWLDataProperty property = getOntology().getOWLDataProperty( propertyName);
        OWLLiteral literal = getOntology().getOWLLiteral( obj);
        linkLiteral(property, literal);
    }

    default OWLLiteral removeLinkedLiteral(OWLDataProperty property) {
        return getLinkedLiteral().remove(property);
    }
    default OWLLiteral removeLinkedLiteral(OWLLiteral literal){
        OWLDataProperty key = getLinkedPropertyLiteral( literal);
        return getLinkedLiteral().remove(key);
    }

    default OWLLiteral getLinkedLiteral(OWLDataProperty property){
        return getLinkedLiteral().get( property);
    }
    default OWLLiteral getLinkedLiteral(String property){
        return getLinkedLiteral( getOntology().getOWLDataProperty( property));
    }
    default String getLinkedDataName(OWLDataProperty property){
        return getOWLName( getLinkedLiteral( property));
    }
    default String getLinkedDataName(String property){
        return getOWLName( getLinkedLiteral( property));
    }

    default OWLDataProperty getLinkedPropertyLiteral(OWLLiteral value){
        for( OWLDataProperty p : getLinkedLiteral().keySet()){
            if( getLinkedLiteral( p).equals( value))
                return p;
        }
        return null;
    }
    default OWLDataProperty getLinkedPropertyLiteral(String value){
        return getLinkedPropertyLiteral( getOntology().getOWLLiteral( value));
    }
    default String getLinkedPropertyLiteralName(OWLLiteral value){
        return getOWLName( getLinkedPropertyLiteral( value));
    }
    default String getLinkedPropertyLiteralName(String value){
        return getOWLName( getLinkedPropertyLiteral( value));
    }

    default OWLLiteral getPropertyLiteral(String propertyName){
        OWLDataProperty prop = getOntology().getOWLDataProperty( propertyName);
        return getPropertyLiteral( prop);
    }
    // calls always ontoRef...Only... todo change for multiple properties
    default OWLLiteral getPropertyLiteral(OWLDataProperty property){
        return getOntology().getOnlyDataPropertyB2Individual( getInstance(), property);
    }

    @Override
    default Semantics.ReadingState readLinkedData(String debug, OWLDataProperty property){
        return new Logger.MappingTry<Semantics.ReadingState>() {
            @Override
            protected Semantics.ReadingState giveAtry() {
                Semantics.ReadingState state = new Semantics.ReadingState();
                OWLLiteral javaValue = getLinkedLiteral( property);
                OWLLiteral semanticValue = getOntology().getOnlyDataPropertyB2Individual(getInstance(), property);

                if( semanticValue == null) { // does not exist
                    if (javaValue == null){
                        state.asNotChanged();
                        debugging( state, javaValue, semanticValue);
                    } else {
                        removeLinkedLiteral( property);
                        state.asAbsent();
                        debugging( state, javaValue, semanticValue);
                    }
                } else {
                    if (javaValue == null){
                        linkLiteral( property, semanticValue);
                        state.asSuccess();
                        debugging( state, javaValue, semanticValue);
                    } else {
                        if ( semanticValue.equals( javaValue)){
                            state.asNotChanged();
                            debugging( state, javaValue, semanticValue);
                        } else{
                            linkLiteral( property, semanticValue);
                            state.asSuccess();
                            debugging( state, javaValue, semanticValue);
                        }
                    }
                }
                return state;
            }
            private void debugging(Semantics.ReadingState state, OWLLiteral java, OWLLiteral owl){
                log(this.getClass().getSimpleName() + "\t WRITES PROPERTY: \"" + getInstanceName()
                        + " (" + debug + ")"
                        + "\t\t " + getInstanceName() + " "
                        + getStringfixedLength( getOWLName( property), LOGGING_NAME_LENGTH, true) + "."
                        + getStringfixedLength( getOWLName( java), LOGGING_SHORT_NAME_LENGTH, false)
                        + "\t(was in ontology: "
                        + getStringfixedLength( getOWLName( property), LOGGING_NAME_LENGTH, true) + "."
                        + getStringfixedLength( getOWLName( owl), LOGGING_SHORT_NAME_LENGTH, false)
                        + ")\t\t[" + state + "]");
            }
        }.perform();
    }

    @Override
    default Semantics.WritingState writeLinkedLiteral(String debug, OWLDataProperty property) {
        return new Logger.MappingTry<Semantics.WritingState>() {
            @Override
            protected Semantics.WritingState giveAtry() {
                Semantics.WritingState state = new Semantics.WritingState();
                OWLLiteral javaValue = getLinkedLiteral( property);
                OWLLiteral semanticValue = getOntology().getOnlyDataPropertyB2Individual(getInstance(), property);

                if( semanticValue == null) { // does not exist
                    if (javaValue == null){
                        state.asNotChanged();
                        debugging( state, javaValue, semanticValue);
                    } else {
                        // ADD
                        getOntology().addDataPropertyB2Individual( getInstance(), property, javaValue);
                        state.asAdded();
                        debugging( state, javaValue, semanticValue);
                    }
                } else {
                    if (javaValue == null){
                        // REMOVE
                        getOntology().removeDataPropertyB2Individual( getInstance(), property, javaValue);
                        state.asRemoved();
                        debugging( state, javaValue, semanticValue);
                    } else {
                        if ( semanticValue.equals( javaValue)){
                            state.asNotChanged();
                            debugging( state, javaValue, semanticValue);
                        } else{
                            // REPLACE
                            getOntology().replaceDataProperty( getInstance(), property, javaValue, semanticValue);
                            state.asUpdated();
                            debugging( state, javaValue, semanticValue);
                        }
                    }
                }
                return state;
            }
            private void debugging(Semantics.WritingState state, OWLLiteral java, OWLLiteral owl){
                log(this.getClass().getSimpleName() + "\t READS PROPERTY: \"" + getInstanceName()
                        + " (" + debug + ")"
                        + "\t\t " + getInstanceName() + " "
                        + getStringfixedLength( getOWLName( property), LOGGING_NAME_LENGTH, true) + "."
                        + getStringfixedLength( getOWLName( owl), LOGGING_SHORT_NAME_LENGTH, false)
                        + "\t(was in java: "
                        + getStringfixedLength( getOWLName( property), LOGGING_NAME_LENGTH, true) + "."
                        + getStringfixedLength( getOWLName( java), LOGGING_SHORT_NAME_LENGTH, false)
                        + ")\t\t[" + state + "]");
            }
        }.perform();
    }

    class SimpleLinkedData extends MORLinkedIndividualDescriptor.SimpleLinkedIndividual
            implements MORLinkedDataDescriptor {

        private LinkedHashMap<OWLDataProperty, OWLLiteral> linkingLiteralMap = new LinkedHashMap<>();

        public SimpleLinkedData(SimpleLinkedData copy) {
            super(copy);
            this.linkingLiteralMap = new LinkedHashMap<OWLDataProperty, OWLLiteral>( copy.linkingLiteralMap);
        }
        public SimpleLinkedData(String ontoRef, String individual, String type) {
            super(ontoRef, individual, type);
        }
        public SimpleLinkedData(OWLClass type) {
            super(type);
        }
        public SimpleLinkedData(String ontoRef, OWLClass type) {
            super(ontoRef, type);
        }
        public SimpleLinkedData(OWLReferences ontoRef, OWLClass type) {
            super(ontoRef, type);
        }
        public SimpleLinkedData(OWLNamedIndividual instance, OWLClass type) {
            super(instance, type);
        }
        public SimpleLinkedData(String ontoRef, String individual, OWLClass type) {
            super(ontoRef, individual, type);
        }
        public SimpleLinkedData(OWLReferences ontoRef, OWLNamedIndividual individual, OWLClass type) {
            super(ontoRef, individual, type);
        }
        public SimpleLinkedData(Collection<?> types) {
            super(types);
        }
        public SimpleLinkedData(String ontoRef, Collection<?> types) {
            super(ontoRef, types);
        }
        public SimpleLinkedData(OWLReferences ontoRef, Collection<?> types) {
            super(ontoRef, types);
        }
        public SimpleLinkedData(OWLNamedIndividual ontoRef, Collection<?> types) {
            super(ontoRef, types);
        }
        public SimpleLinkedData(String ontoRef, String individual, Collection<?> types) {
            super(ontoRef, individual, types);
        }
        public SimpleLinkedData(OWLReferences ontoRef, OWLNamedIndividual individual, Collection<?> types) {
            super(ontoRef, individual, types);
        }

        @Override
        public LinkedHashMap<OWLDataProperty, OWLLiteral> getLinkedLiteral() {
            return linkingLiteralMap;
        }

        @Override
        public SimpleLinkedData copy(){
            return new SimpleLinkedData( this);
        }

        @Override
        public boolean equals(Object o) { // true if data properties & super (= ontoRef, instance, types, object properties) are equals
            if (this == o) return true;
            if (!(o instanceof SimpleLinkedData)) return false;
            if (!super.equals(o)) return false;

            SimpleLinkedData that = (SimpleLinkedData) o;

            boolean v = linkingLiteralMap != null ? linkingLiteralMap.equals(that.linkingLiteralMap) : that.linkingLiteralMap == null;
            return v & super.equals( o);
        }
        @Override
        public int hashCode() {
            int result = super.hashCode();
            result = 31 * result + (linkingLiteralMap != null ? linkingLiteralMap.hashCode() : 0);
            return result;
        }

        @Override
        public String toString() {
            return super.toString() + getStringfixedLength( " with data properties: ", LOGGING_LONG_NUMBER_LENGTH, true)
                    + linkingLiteralMap;
        }
    }
}
