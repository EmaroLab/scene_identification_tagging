package it.emarolab.scene_identification_tracking.semanticSceneLibrary.old.core.aMORDescriptor;

import it.emarolab.amor.owlInterface.OWLReferences;
import it.emarolab.amor.owlInterface.OWLReferencesInterface;
import it.emarolab.scene_identification_tracking.semanticSceneLibrary.old.Logger;
import it.emarolab.scene_identification_tracking.semanticSceneLibrary.old.core.Semantics;
import org.semanticweb.owlapi.model.*;

import java.util.HashSet;
import java.util.Set;

// hp: instance should be available in the ontology
public interface MORDescriptor<I extends OWLObject> extends Semantics.Descriptor<OWLReferences, I>  {

    default <O extends OWLObject> String getOWLName(O obj) {
        if (obj == null)
            return "";
        return getOntology().getOWLObjectName(obj);
    }
    default Set<String> getOWLName(Set<? extends OWLObject> objs) {
        if (objs == null)
            return new HashSet<>();
        return getOntology().getOWLObjectName(objs);
    }

    I getDefaultInstance();
    default String getDefaultInstanceName() {
        return getOWLName( getDefaultInstance());
    }

    default String getInstanceName() {
        return getOWLName(getInstance());
    }

    boolean setInstance( String name);

    default String getOntologyName() {
        return getOntology().getReferenceName();
    }

    default boolean setOntology(String ontoName) { // set ontology name
        if (ontoName == null) {
            Logger.SITBase.logERROR(ontoName + "\" aMOR ontology cannot be refereed by: 'null' !");
            return false;
        }
        if (ontoName.isEmpty()) {
            Logger.SITBase.logERROR(ontoName + "\" aMOR ontology cannot be refereed by an empty name !");
            return false;
        }
        if (!OWLReferencesInterface.OWLReferencesContainer.isInstance(ontoName)) {
            Logger.SITBase.logERROR(ontoName + "\" aMORObject reference not found!");
            return false;
        }

        // only for first initialisation of the owlClass
        boolean callDefaultInstance = false;
        if (getOntology() == null & getInstance() == null)
            callDefaultInstance = true;

        // actual setting in error free mannar
        setOntology((OWLReferences) OWLReferencesInterface.OWLReferencesContainer.getOWLReferences(ontoName));

        if (callDefaultInstance) // set also the owlClass
            setInstance(getDefaultInstance());

        return true;
    }

    default boolean resetOntology(String ontoName) { // set ontology name and instance
        if (setOntology(ontoName)) {
            setInstance( getDefaultInstance());
            return true;
        }
        return false;
    }
    default boolean resetOntology(String ontoName, String instanceName) { // set ontology name and instance
        if (setOntology(ontoName)) {
            setInstance( instanceName);
            return true;
        }
        return false;
    }
    default boolean resetOntology(OWLReferences ontoRef) { // set ontology name and instance
        if (setOntology(ontoRef)) {
            setInstance(getDefaultInstance());
            return true;
        }
        return false;
    }
    default boolean resetOntology(OWLReferences ontoRef, I instance) { // set ontology name and instance
        if (setOntology(ontoRef)) {
            setInstance(instance);
            return true;
        }
        return false;
    }

    default void updateReasoner() {
        this.getOntology().synchronizeReasoner();
    }


    interface MORIndividualDescriptor extends MORDescriptor< OWLNamedIndividual> {
        @Override
        default boolean setInstance(String individualName) {
            if (individualName != null & getOntology() != null)
                this.setInstance(getOntology().getOWLIndividual(individualName));
            else {
                Logger.SITBase.logWARNING("OWLIndividual not set for new name: " + individualName);
                return false;
            }
            return true;
        }
    }

    class SimpleIndividual extends Logger.SITBase implements MORIndividualDescriptor {

        private static final String DEFAULT_INDIVIDUAL_NAME = "I-";

        private OWLReferences ontoRef;
        private OWLNamedIndividual individual;

        public SimpleIndividual(SimpleIndividual copy) {
            this.ontoRef = copy.ontoRef;
            this.individual = copy.individual;
        }
        public SimpleIndividual() {
        }
        public SimpleIndividual(String ontoRef) {
            this.setOntology( ontoRef);
        }
        public SimpleIndividual(OWLReferences ontoRef) {
            this.setOntology( ontoRef); // set also owlClass since both fields are null
        }
        public SimpleIndividual(OWLNamedIndividual individual) {
            this.setInstance( individual);
        }
        public SimpleIndividual(String ontoRef, String individual) {
            this.resetOntology( ontoRef, individual);
        }
        public SimpleIndividual(OWLReferences ontoRef, OWLNamedIndividual individual) {
            this.resetOntology( ontoRef, individual); // set also owlClass since both fields are null
        }

        @Override
        public OWLNamedIndividual getDefaultInstance() {
            return getOntology().getOWLIndividual( DEFAULT_INDIVIDUAL_NAME);
        }

        @Override
        public OWLReferences getOntology() {
            if( ontoRef == null)
                logWarning("This description has 'null' ontology reference !!!");
            return ontoRef;
        }
        @Override
        public OWLNamedIndividual getInstance() {
            if( ontoRef == null)
                logWarning("This description has 'null' instance reference !!!");
            return individual;
        }

        @Override
        public boolean setOntology(OWLReferences ontology) {
            if (ontology == null){
                logERROR( "Cannot set 'null' ontology to the simple owlClass descriptor.");
                return false;
            }
            this.ontoRef = ontology;
            return true;
        }
        @Override
        public boolean setInstance(OWLNamedIndividual instance) {
            if (instance == null){
                logERROR( "Cannot set 'null' ontology to the simple owlClass descriptor.");
                return false;
            }
            this.individual = instance;
            return true;
        }

        @Override
        public boolean equals(Object o) { // true if individual & ontoRef name are equal;
            if (this == o) return true;
            if (!(o instanceof SimpleIndividual)) return false;

            SimpleIndividual that = (SimpleIndividual) o;

            if (ontoRef != null ? !ontoRef.getReferenceName().equals(that.ontoRef.getReferenceName()) : that.ontoRef != null)
                return false;
            return individual != null ? individual.equals(that.individual) : that.individual == null;
        }
        @Override
        public int hashCode() {
            int result = ontoRef != null ? ontoRef.hashCode() : 0;
            result = 31 * result + (individual != null ? individual.hashCode() : 0);
            return result;
        }

        @Override
        public SimpleIndividual copy() {
            return new SimpleIndividual( this);
        }

        @Override
        public String toString() {
            return Logger.getfixedStringLength( getInstanceName(), Logger.SITBase.LOGGING_NUMBER_LENGTH, true)
                    + "@" + Logger.getfixedStringLength( getOntologyName(), Logger.SITBase.LOGGING_SHORT_NAME_LENGTH, false);
        }
    }


    interface MORClassDescriptor extends MORDescriptor< OWLClass> {

        @Override
        default boolean setInstance(String individualName) {
            if (individualName != null & getOntology() != null)
                this.setInstance(getOntology().getOWLClass(individualName));
            else {
                Logger.SITBase.logWARNING("OWLIndividual not set for new name: " + individualName);
                return false;
            }
            return true;
        }
    }

    class SimpleClass extends Logger.SITBase implements MORClassDescriptor {

        private static final String DEFAULT_CLASS_NAME = "C:";

        private OWLReferences ontoRef;
        private OWLClass owlClass;

        public SimpleClass(SimpleClass copy) {
            this.ontoRef = copy.ontoRef;
            this.owlClass = copy.owlClass;
        }
        public SimpleClass() {
        }
        public SimpleClass(String ontoRef) {
            this.setOntology( ontoRef);
        }
        public SimpleClass(OWLReferences ontoRef) {
            this.setOntology( ontoRef); // set also owlClass since both fields are null
        }
        public SimpleClass(OWLClass owlClass) {
            this.setInstance( owlClass);
        }
        public SimpleClass(String ontoRef, String owlClass) {
            this.resetOntology( ontoRef, owlClass);
        }
        public SimpleClass(OWLReferences ontoRef, OWLClass owlClass) {
            this.resetOntology( ontoRef, owlClass); // set also owlClass since both fields are null
        }

        @Override
        public OWLClass getDefaultInstance() {
            return getOntology().getOWLClass( DEFAULT_CLASS_NAME);
        }

        @Override
        public OWLReferences getOntology() {
            if( ontoRef == null)
                logWarning("This description has 'null' ontology reference !!!");
            return ontoRef;
        }
        @Override
        public OWLClass getInstance() {
            if( ontoRef == null)
                logWarning("This description has 'null' instance reference !!!");
            return owlClass;
        }

        @Override
        public boolean setOntology(OWLReferences ontology) {
            if (ontology == null){
                logERROR( "Cannot set 'null' ontology to the simple owlClass descriptor.");
                return false;
            }
            this.ontoRef = ontology;
            return true;
        }
        @Override
        public boolean setInstance(OWLClass instance) {
            if (instance == null){
                logERROR( "Cannot set 'null' ontology to the simple owlClass descriptor.");
                return false;
            }
            this.owlClass = instance;
            return true;
        }

        @Override
        public SimpleClass copy() {
            return new SimpleClass( this);
        }

        @Override // equal if class and reference names are equals
        public boolean equals(Object o) {
            if (this == o) return true;
            if (!(o instanceof SimpleClass)) return false;

            SimpleClass that = (SimpleClass) o;

            if (ontoRef != null ? !ontoRef.getReferenceName().equals(that.ontoRef.getReferenceName()) : that.ontoRef != null) return false;
            return owlClass != null ? owlClass.equals(that.owlClass) : that.owlClass == null;
        }
        @Override
        public int hashCode() {
            int result = ontoRef != null ? ontoRef.hashCode() : 0;
            result = 31 * result + (owlClass != null ? owlClass.hashCode() : 0);
            return result;
        }

        @Override
        public String toString() {
            return Logger.getfixedStringLength( getInstanceName(), Logger.SITBase.LOGGING_NUMBER_LENGTH, true)
                    + "@" + Logger.getfixedStringLength( getOntologyName(), Logger.SITBase.LOGGING_SHORT_NAME_LENGTH, false);
        }
    }

    class SWRLManager {
        public Set<SWRLAtom> antecedent, postecedent;
        private String ontologyIri;
        private OWLReferences ontology;

        public SWRLManager(OWLReferences ontology) {
            this.ontology = ontology;
            antecedent = new HashSet<SWRLAtom>();
            postecedent = new HashSet<SWRLAtom>();
            ontologyIri = ontology.getIriOntologyPath().toString();
        }

        // to get a variable
        public SWRLVariable getVariable(String var) {
            return ontology.getOWLFactory().getSWRLVariable( IRI.create(ontologyIri + "#" + var));
        }

        public SWRLIndividualArgument getConst(OWLNamedIndividual individual) {
            return (ontology.getOWLFactory().getSWRLIndividualArgument(individual));
        }

        public void addRoole() {
            SWRLRule rule = ontology.getOWLFactory().getSWRLRule(antecedent, postecedent); //Collections.singleton(postecedent));
            ontology.applyOWLManipulatorChangesAddAxiom(rule);
        }

        // to look for individual into class (i.e. cl( ?var))
        private SWRLClassAtom addClassAtom(OWLClass cl, SWRLVariable var, Set<SWRLAtom> collection) {
            SWRLClassAtom classAtom = ontology.getOWLFactory().getSWRLClassAtom(cl, var);
            collection.add(classAtom);
            return classAtom;
        }

        // to look for individual into class (i.e. cl( ?var))
        private SWRLClassAtom addClassAtom(OWLClass cl, SWRLIndividualArgument var, Set<SWRLAtom> collection) {
            SWRLClassAtom classAtom = ontology.getOWLFactory().getSWRLClassAtom(cl, var);
            collection.add(classAtom);
            return classAtom;
        }

        public SWRLClassAtom addClassCondition(OWLClass cl, SWRLVariable var) {
            return addClassAtom(cl, var, antecedent);
        }

        protected SWRLClassAtom addClassCondition(OWLClass cl, SWRLIndividualArgument var) {
            return addClassAtom(cl, var, antecedent);
        }

        protected SWRLClassAtom addClassInferation(OWLClass cl, SWRLVariable var) {
            return addClassAtom(cl, var, postecedent);
        }

        public SWRLClassAtom addClassInferation(OWLClass cl, SWRLIndividualArgument var) {
            return addClassAtom(cl, var, postecedent);
        }

        // to look for the value of an object property (i.e. objProp())
        public SWRLObjectPropertyAtom addObjectPropertyAtom(SWRLVariable preInd, OWLObjectProperty prop, SWRLVariable postInd, Set<SWRLAtom> collection) {
            SWRLObjectPropertyAtom dataRule = ontology.getOWLFactory().getSWRLObjectPropertyAtom(prop, preInd, postInd);
            collection.add(dataRule);
            return dataRule;
        }

        protected SWRLObjectPropertyAtom addObjectPropertyCondition(SWRLVariable preInd, OWLObjectProperty prop, SWRLVariable postInd) {
            return addObjectPropertyAtom(preInd, prop, postInd, antecedent);
        }

        protected SWRLObjectPropertyAtom addObjectPropertyInferation(SWRLVariable preInd, OWLObjectProperty prop, SWRLVariable postInd) {
            return addObjectPropertyAtom(preInd, prop, postInd, postecedent);
        }

        // to look for the value of an object property (i.e. objProp())
        private SWRLObjectPropertyAtom addObjectPropertyAtom(SWRLIndividualArgument preInd, OWLObjectProperty prop, SWRLVariable postInd, Set<SWRLAtom> collection) {
            SWRLObjectPropertyAtom dataRule = ontology.getOWLFactory().getSWRLObjectPropertyAtom(prop, preInd, postInd);
            collection.add(dataRule);
            return dataRule;
        }

        public SWRLObjectPropertyAtom addObjectPropertyCondition(SWRLIndividualArgument preInd, OWLObjectProperty prop, SWRLVariable postInd) {
            return addObjectPropertyAtom(preInd, prop, postInd, antecedent);
        }

        protected SWRLObjectPropertyAtom addObjectPropertyInferation(SWRLIndividualArgument preInd, OWLObjectProperty prop, SWRLVariable postInd) {
            return addObjectPropertyAtom(preInd, prop, postInd, postecedent);
        }

        // to look for the value of an object property (i.e. objProp())
        private SWRLObjectPropertyAtom addObjectPropertyAtom(SWRLVariable preInd, OWLObjectProperty prop, SWRLIndividualArgument postInd, Set<SWRLAtom> collection) {
            SWRLObjectPropertyAtom dataRule = ontology.getOWLFactory().getSWRLObjectPropertyAtom(prop, preInd, postInd);
            collection.add(dataRule);
            return dataRule;
        }

        protected SWRLObjectPropertyAtom addObjectPropertyCondition(SWRLVariable preInd, OWLObjectProperty prop, SWRLIndividualArgument postInd) {
            return addObjectPropertyAtom(preInd, prop, postInd, antecedent);
        }

        protected SWRLObjectPropertyAtom addObjectPropertyInferation(SWRLVariable preInd, OWLObjectProperty prop, SWRLIndividualArgument postInd) {
            return addObjectPropertyAtom(preInd, prop, postInd, postecedent);
        }


        public Set<SWRLAtom> getAntecedent() {
            return antecedent;
        }

        public Set<SWRLAtom> getPostecedent() {
            return postecedent;
        }
    }
}
