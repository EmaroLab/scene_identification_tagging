package it.emarolab.scene_identification_tracking.semanticSceneLibrary.old.core.aMORDescriptor;

import it.emarolab.amor.owlInterface.OWLReferences;
import it.emarolab.scene_identification_tracking.semanticSceneLibrary.old.Logger;
import it.emarolab.scene_identification_tracking.semanticSceneLibrary.old.core.Semantics;
import org.semanticweb.owlapi.model.OWLClass;
import org.semanticweb.owlapi.model.OWLNamedIndividual;

import java.util.Collection;
import java.util.HashSet;
import java.util.Set;

public interface MORTypedIndividualDescriptor
        extends MORDescriptor.MORIndividualDescriptor,
        Semantics.TypedInstanceDescriptor<OWLReferences, OWLNamedIndividual, OWLClass> {

    @Override
    Set<OWLClass> getTypes();
    @Override
    Semantics.TypedInstanceDescriptor<OWLReferences, OWLNamedIndividual, OWLClass> copy();

    default Set<String> getTypesName(){ // todo add other names
        return getOntology().getOWLObjectName( getTypes());
    }

    boolean addType(OWLClass toAdd);
    default boolean addType( String toAdd){
        OWLClass cl = getOntology().getOWLClass( toAdd);
        return addType( cl);
    }
    default boolean addTypes( Collection<?> toAdd){ // reduce String to OWLClasses or skip
        boolean flag = false;
        for( Object item : toAdd){
            if( item instanceof String)
                flag = addType( ( String) item);
            else if( item instanceof OWLClass)
                flag = flag & addType( ( OWLClass) item);
            else Logger.SITBase.logWARNING( "Cannot add type " + item + " to object: " + this);
        }
        return flag;
    }

    boolean removeType(OWLClass toRemove);
    default boolean removeTypes(String toRemove){
        OWLClass cl = getOntology().getOWLClass(toRemove);
        return removeType( cl);
    }
    default boolean removeTypes( Collection<?> toRemove){ // reduce String to OWLClasses or skip
        boolean flag = false;
        for( Object item : toRemove){
            if( item instanceof String)
                flag = removeTypes( ( String) item);
            else if( item instanceof OWLClass)
                flag = flag & removeType( ( OWLClass) item);
            else Logger.SITBase.logWARNING( "Cannot remove type " + item + " to object: " + this);
        }
        return flag;
    }

    default void clearTypes(){
        getTypes().clear();
    }

    boolean containsTypes(OWLClass toCheck);
    default boolean containsTypes( String toCheck){
        OWLClass cl = getOntology().getOWLClass(toCheck);
        return containsTypes( cl);
    }
    default boolean containsTypes( Collection<?> toCheck){ // reduce String to OWLClasses or skip
        boolean flag = false;
        for( Object item : toCheck){
            if( item instanceof String)
                flag = containsTypes( ( String) item);
            else if( item instanceof OWLClass)
                flag = flag & containsTypes( ( OWLClass) item);
            else Logger.SITBase.logWARNING( "Cannot check type " + item + " to object: " + this);
        }
        return flag;
    }
    // contains only that one !!!
    default boolean isAllTypes(Collection<?> toAdd){ // reduce String to OWLClasses or skip
        Set< OWLClass> clToAdd = new HashSet<>();
        for( Object item : toAdd){
            if( item instanceof String)
                clToAdd.add( getOntology().getOWLClass( ( String) item));
            else if( item instanceof OWLClass)
                clToAdd.add( ( OWLClass) item);
            else Logger.SITBase.logWARNING( "Cannot check type " + item + " to object: " + this);
        }

        /* return true iff all classes toAdd are also in this.getTypes();
        for(OWLClass a : getTypes()){
            boolean find = false;
            for (OWLClass t : clToAdd)
                if( a.equals( t)){
                    find = true;
                    break;
                }
            if( ! find)
                return false;
        }
        return true;
        */
        return getTypes().equals( clToAdd);
    }

    default Semantics.WritingState writeType(String debuggingInfo){
        return new Logger.MappingTry<Semantics.WritingState>() {
            protected Semantics.WritingState giveAtry() {
                Semantics.WritingState state = new Semantics.WritingState(); // as inconsistent
                Set<OWLClass> javaValue = new HashSet<>( getTypes());
                Set<OWLClass> semanticValue = getOntology().getIndividualClasses( getInstance());

                if( javaValue != null) {
                    if (semanticValue != null && !semanticValue.isEmpty()) {
                        // both red, nothing changed
                        if( semanticValue.equals( javaValue)) {
                            state.asNotChanged();
                            debuging( state, javaValue, semanticValue);
                        } else {
                            HashSet<OWLClass> semanticValueCopy = new HashSet<>(semanticValue);
                            for (OWLClass cl : javaValue){
                                if (semanticValue.contains( cl)){
                                    // both read, not changed
                                    Semantics.WritingState notChangedState = new Semantics.WritingState().asNotChanged();
                                    state.merge( notChangedState);
                                    // it does not do nothing on the set
                                    debuging( notChangedState, javaValue, semanticValue);
                                    // take track of what has not beet added, to be removed later
                                    semanticValueCopy.remove( cl);
                                } else {
                                    // both read, added
                                    Semantics.WritingState addState = new Semantics.WritingState().asAdded();
                                    getOntology().addIndividualB2Class( getInstance(), cl);
                                    state.merge( addState);
                                    debuging( addState, javaValue, semanticValue);
                                }
                            }
                            for (OWLClass rm : semanticValueCopy){
                                // remove remaining value
                                Semantics.WritingState removeState = new Semantics.WritingState().asRemoved();
                                getOntology().removeIndividualB2Class( getInstance(), rm);
                                state.merge( removeState);
                                debuging( removeState, javaValue, semanticValue);
                            }
                        }
                    } else {
                        // nothing read, nothing changed
                        if ( javaValue.isEmpty()){
                            state.asNotChanged();
                            debuging( state, javaValue, semanticValue);
                        } else {
                            // nothing read, write all
                            for (OWLClass cl : javaValue){
                                Semantics.WritingState addState = new Semantics.WritingState().asAdded();
                                getOntology().addIndividualB2Class( getInstance(), cl);
                                state.merge( addState);
                                debuging( addState, javaValue, semanticValue);
                            }
                        }
                    }
                } else { // java cannot be read
                    logERROR( "Cannot write null types for: " + getInstanceName());
                    state.asError();
                }
                return state;
            }
            private void debuging(Semantics.WritingState state, Set< OWLClass> java, Set< OWLClass> owl){
                log( this.getClass().getSimpleName() + "\t WRITES TYPE: \"" + getInstanceName()
                        + " (" + debuggingInfo + ")"
                        + "\t\t " + getOWLName( java)
                        + "\t(was in ontology: " + getOWLName( owl) + ")"
                        + "\t\t[" + state + "]");
            }
        }.perform();
    }

    default Semantics.ReadingState readType(String debuggingInfo){
        return new Logger.MappingTry<Semantics.ReadingState>() {
            protected Semantics.ReadingState giveAtry() {
                Semantics.ReadingState state = new Semantics.ReadingState(); // as inconsistent
                Set<OWLClass> javaValue = new HashSet<>(getTypes());
                Set<OWLClass> semanticValue = getOntology().getIndividualClasses(getInstance()); // it may be reduced during the computations

                if (javaValue != null) {
                    if (semanticValue != null && !semanticValue.isEmpty()) {
                        // both red, nothing changed
                        if (semanticValue.equals(javaValue)) {
                            state.asNotChanged();
                            debuging(state, javaValue, semanticValue);
                        } else {
                            Set<OWLClass> javaValueCopy = new HashSet<>( javaValue);
                            for (OWLClass cl : semanticValue) {
                                if (javaValue.contains(cl)) {
                                    // both read, not changed
                                    Semantics.ReadingState notChangedState = new Semantics.ReadingState().asNotChanged();
                                    state.merge(notChangedState);
                                    // it does not do nothing on the set
                                    debuging(notChangedState, javaValue, semanticValue);
                                    // take track of what has not beet added, to be removed later
                                    javaValueCopy.remove(cl);
                                } else {
                                    // both read, added
                                    Semantics.ReadingState addState = new Semantics.ReadingState().asSuccess();
                                    addType(cl);
                                    state.merge(addState);
                                    debuging(addState, javaValue, semanticValue);
                                }
                            }
                            for (OWLClass rm : javaValueCopy) {
                                // remove remaining value
                                Semantics.ReadingState removeState = new Semantics.ReadingState().asAbsent();
                                removeType(rm);
                                state.merge(removeState);
                                debuging(removeState, javaValue, semanticValue);
                            }
                        }
                    } else {
                        // nothing read, nothing changed
                        if (javaValue.isEmpty()) {
                            state.asNotChanged();
                            debuging(state, javaValue, semanticValue);
                        } else {
                            // nothing read, remove all
                            clearTypes();
                            Semantics.ReadingState addState = new Semantics.ReadingState().asAbsent();
                            debuging(addState, javaValue, semanticValue);
                        }
                    }
                } else { // java cannot be read
                    logERROR("Cannot write null types for: " + getInstanceName());
                    state.asError();
                }
                return state;
            }

            private void debuging(Semantics.ReadingState state, Set<OWLClass> java, Set<OWLClass> owl) {
                log(this.getClass().getSimpleName() + "\t READS TYPE: \"" + getInstanceName()
                        + " (" + debuggingInfo + ")"
                        + "\t\t " + getOWLName(owl)
                        + "\t(was in java: " + getOWLName(java) + ")"
                        + "\t\t[" + state + "]");
            }
        }.perform();
    }

    class SimpleTypedIndividual extends SimpleIndividual
            implements MORTypedIndividualDescriptor {

        private Set<OWLClass> types = new HashSet<>();

        public SimpleTypedIndividual(SimpleTypedIndividual copy) {
            super(copy);
            this.types = new HashSet<>( copy.types);
        }

        public SimpleTypedIndividual(String ontoRef, String individual, String type) {
            super(ontoRef, individual);
            addType( type);
        }

        public SimpleTypedIndividual(OWLClass type) {
            super();
            addType( type);
        }
        public SimpleTypedIndividual(String ontoRef, OWLClass type) {
            super(ontoRef);
            addType( type);
        }
        public SimpleTypedIndividual(OWLReferences ontoRef, OWLClass type) {
            super(ontoRef);
            addType( type);
        }
        public SimpleTypedIndividual(OWLNamedIndividual instance, OWLClass type) {
            super(instance);
            addType( type);
        }
        public SimpleTypedIndividual(String ontoRef, String individual, OWLClass type) {
            super(ontoRef, individual);
            addType( type);
        }
        public SimpleTypedIndividual(OWLReferences ontoRef, OWLNamedIndividual individual, OWLClass type) {
            super(ontoRef, individual);
            addType( type);
        }

        public SimpleTypedIndividual(Collection<?> types) {
            super();
            addTypes( types);
        }
        public SimpleTypedIndividual(String ontoRef, Collection<?> types) {
            super(ontoRef);
            addTypes( types);
        }
        public SimpleTypedIndividual(OWLReferences ontoRef, Collection<?> types) {
            super(ontoRef);
            addTypes( types);
        }
        public SimpleTypedIndividual(OWLNamedIndividual ontoRef, Collection<?> types) {
            super(ontoRef);
            addTypes( types);
        }
        public SimpleTypedIndividual(String ontoRef, String individual, Collection<?> types) {
            super(ontoRef, individual);
            addTypes( types);
        }
        public SimpleTypedIndividual(OWLReferences ontoRef, OWLNamedIndividual individual, Collection<?> types) {
            super(ontoRef, individual);
            addTypes( types);
        }

        @Override
        public Set<OWLClass> getTypes() {
            return types;
        }

        @Override
        public boolean addType(OWLClass toAdd) {
            return types.add( toAdd);
        }

        @Override
        public boolean removeType(OWLClass toRemove) {
            return types.remove( toRemove);
        }

        @Override
        public boolean containsTypes(OWLClass toCheck) {
            return types.contains( toCheck);
        }

        @Override
        public SimpleTypedIndividual copy(){
            return new SimpleTypedIndividual( this);
        }

        @Override
        public boolean equals(Object o) { // true if types & super (= ontoRef, instance) are equals
            if (this == o) return true;
            if (!(o instanceof SimpleTypedIndividual)) return false;
            if (!super.equals(o)) return false;

            SimpleTypedIndividual that = (SimpleTypedIndividual) o;
            boolean v = getTypes() != null ? getTypes().equals(that.getTypes()) : that.getTypes() == null;
            return v & super.equals( o);
        }
        @Override
        public int hashCode() {
            int result = super.hashCode();
            result = 31 * result + (getTypes() != null ? getTypes().hashCode() : 0);
            return result;
        }

        @Override
        public String toString() {
            return super.toString() + getStringfixedLength( " with type: ", LOGGING_LONG_NUMBER_LENGTH, true)
                    + getTypesName();
        }
    }
}
